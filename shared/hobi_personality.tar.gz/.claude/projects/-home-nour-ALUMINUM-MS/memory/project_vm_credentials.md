---
name: بيانات دخول VM Rabos + الخدمات
description: كلمات مرور Windows VM + SQL + Guacamole لسرعة الاستخدام
type: reference
originSessionId: 66234412-84da-4ebc-80f9-811f6a812f69
---
# 🔐 Credentials — VM Rabos و الخدمات

## Windows VM (Rabos) — على Samsung SSD
- **User:** `RaBoS`
- **Password:** `Mhmoud@123` ⚠️ ملاحظة: **Mhmoud** بدون a (مش Mahmoud)
- **Tailscale IP:** `100.114.214.16` (hostname: `rabos-1`)
- **RDP port:** 3389

## Guacamole (HTML5 RDP gateway)
- **URL:** `https://aluminum-nour.ngrok.pro/guac/` (عبر pm_server)
- **User:** `nour` / **Pass:** `nour2026`
- **connection name:** `nourwork` (auto-connect لـ VM Rabos)
- **user-mapping.xml:** `/opt/guacamole/home/user-mapping.xml`

## SQL Server Docker (ra-sqlserver)
- **sa password:** `NourRa2026!Strong#Pass`
- **host:** `127.0.0.1:1433`
- **DBs:** RaConfig, RaMaterials, RaProjects

## ملاحظات تاريخية
- سابقاً كانت `1559` ثم غيّرها محمود لـ `Mhmoud@123`
- الأصلية (قبل التغيير) كانت في memory session_2026-04-16
