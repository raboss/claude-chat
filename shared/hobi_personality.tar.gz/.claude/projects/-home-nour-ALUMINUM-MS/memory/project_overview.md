---
name: ALUMINOR Project Overview
description: Complete architecture and structure of the ALUMINOR aluminum/glass project management system
type: project
---

# ALUMINOR - Integrated Solutions (نظام إدارة مشاريع الألمنيوم والزجاج)

## Project Structure
- **Main project**: `pm_server/` (Node.js + Express, port 3001)
- **Android app**: `pm_android_app/` (WebView wrapper - to be developed later)
- **Client files**: `ملفات العملاء/` (auto-generated from the project)
- **Backup**: `pm_server_backup_2026-03-19/` (IGNORE)

## Server (server.js)
- Express server on port 3001, data stored as JSON files in `data/` directory
- APIs: CRUD `/api/data`, export/import, client folders (hierarchical: company > region > gallery > client), file upload, activity log
- Client folder root: `../ملفات العملاء`
- File size limits: 50MB general, 20MB site photos
- Activity log: max 200 entries

## Frontend Structure (public/)
- Single page app: `index.html` (1471 lines)
- 15 JS modules in `public/js/` (00-14)
- 1 CSS file: `public/css/style.css`
- PWA: `sw.js`, `manifest.json`
- Report page: `project-report.html`
- Development copy: `public/تطوير/`

## 7 Main Pages
1. **Projects** (page-projects): Dashboard, project cards, stats, CRUD
2. **Reports** (page-reports): 5 tabs - overview, weekly, monthly, client, timeline
3. **Saved** (page-saved): Archived production, materials, weekly reports
4. **Documents** (page-documents): Generate client reports, extracts, forms, POs, timelines, measurements
5. **Installations** (page-installations): 4 tabs - measurements, defects, delivery, maintenance
6. **Drawings** (page-drawings): CAD tool for window/door design
7. **Settings** (page-settings): 13 config sections

## Tech Stack
- Backend: Node.js, Express, Multer, xlsx
- Frontend: Vanilla JS, Chart.js, XLSX.js
- Storage: JSON files on server + localStorage fallback
- PWA with service worker (cache v99)
- Font: Cairo (Google Fonts)

**Why:** Understanding the full project structure is essential for any modifications.
**How to apply:** Always work within `pm_server/` directory. Ignore backup folder. Android app development is deferred.
