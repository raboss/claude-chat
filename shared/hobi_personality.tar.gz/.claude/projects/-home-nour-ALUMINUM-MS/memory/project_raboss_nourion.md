---
name: مشروع رابوس NouRion + تقييم الشغل
description: ملخص شغل رابوس NouRion SPA + تقييم + مقارنة مع الخطة الرسمية
type: project
originSessionId: f052689f-fb13-4935-9127-120e6fdec75b
---
## شغل رابوس (حتى 10 أبريل 2026)

### ما سلّمه:
1. **Schema الكامل لـ Ra Workshop:**
   - `claude_chat/shared/ra_schema.sql` — 3 قواعد
   - `claude_chat/shared/ra_tables_explanation.md` — شرح عربي مفصّل
   - `claude_chat/shared/ra_sample_data.json` — بيانات نموذج
   - RaConfig (24 جدول), RaMaterials (127), RaProjects (19)

2. **NouRion SPA:**
   - `app.html` — Single Page Application
   - Login احترافي + auth (scrypt + session + CSRF)
   - CRUD كامل للمشاريع/العملاء/الموظفين/أنواع النماذج
   - i18n AR/EN + RTL/LTR تلقائي
   - خطوط محلية (بدون Google Fonts)
   - 930 test passing (unit + e2e)
   - Deploy scripts جاهزة (setup.sh + nginx + systemd)

### التقييم:
- **ممتاز:** جودة الكود + Testing + Auth + i18n
- **نقاط تحتاج تصحيح:**
  - NouRion منفصل عن pm_server — لازم ندمج
  - شغل على LocalDB (لابتوب) مش Docker عندي
  - لا Ra.exe integration حقيقي
  - الصفحات لسا مش مطابقة لخطة محمود (18 قسم مطلوب vs 3-4 حالياً)

## خطة محمود الرسمية (من 15 أبريل)
- `/home/nour/ALUMINUM-MS/presentation/01_PLAN_DETAILED_AR.md` (28KB)
- 18 قسم — من عرض السعر حتى الضمان
- هامش شركة 20% ثابت + نسبة مندوب قابلة للخصم
- أمتار إلكترونية بلوتوث (hardware قادم)

## المقارنة
- NouRion غطى: SPA + auth + CRUD بسيط (المرحلة 0)
- ناقص: 15+ قسم كامل (المشتريات، الإنتاج، التركيبات، الرواتب، المخزون، التقارير...)

## الأسئلة المطروحة على رابوس
1. دمج NouRion في pm_server ولّا العكس؟
2. تجربته مع `mssql` npm package؟
3. نقل نظام auth لـ pm_server؟
4. Testing harness عام للمشروع؟

## الرسائل المرسلة
- `from_nour_to_raboss/10_nourwork_kickoff.md` — أول تواصل
- `from_nour_to_raboss/11_full_brief_evaluation.md` — البريف الشامل (commit 2e6a6fc)

## ملفات مرفوعة في shared/
- `shared/plan/01_PLAN_DETAILED_AR.md/pdf/docx`
- `shared/plan/02_PRESENTATION.pdf`
- `shared/ra_schema.sql` + `ra_tables_explanation.md` + `ra_sample_data.json`
