---
name: حالة مباشرة — الألمنيوم
description: آخر حالة مشروع الألمنيوم — تحديث كل دقيقة
type: project
---

# آخر تحديث: 2026-04-27 08:40 UTC

## السيرفر: شغال (pm_server port 3001)

## VM Rabos: unknown
- IP: 192.168.122.106
- RDP socat-rdp: active
- Tailscale rabos-1: online
- Auto-login: RaBoS / 1559
- اتصال الآيباد: 100.104.45.91 → RaBoS / 1559

## الخدمات المثبّتة تلقائي:
- ✅ socat-rdp.service (systemd, enabled)
- ✅ VM autostart
- ✅ xrdp disabled
- ✅ Windows: Tailscale auto, RDP auto, auto-login
- ✅ WinRM مفعّل (port 5985)
