---
name: Custody/Accounts Page Implementation
description: Complete custody (العهدة) page with receive, distribute, invoices, employee accounts tabs
type: project
---

## صفحة الحسابات (19-custody.js)

### 4 Tabs:
1. **استلام العهدة** — receive custody from company
2. **توزيع العهدة** — distribute to employees (main distributions only, transfers don't show here)
3. **تسوية الفواتير** — admin settles invoices (✅ settle / ❌ reject per invoice)
4. **حسابات الموظفين** — per-employee account view

### Key Logic:
- Transfers (employee→employee) do NOT reduce the original employee's balance
- Transfers don't appear in main distribution tab
- Employee dropdown in invoice form: shows ONLY people that employee transferred to (not all employees)
- Admin sees all employees in dropdown
- Settlement (تسوية) buttons appear ONLY in "تسوية الفواتير" tab — NEVER in employee accounts
- Employee can: edit ✏️, delete 🗑️ (if not settled), view 👁️
- Admin can: settle ✅, reject ❌, edit ✏️, delete 🗑️, view 👁️, download ⬇️
- Rejected invoices show red badge with reason at employee's account
- Invoice form has "اختر العهدة" dropdown showing specific custody amounts (850, 500, etc.)
- Photo upload via /api/upload-custody-invoice endpoint
- Photo view via /api/file?path=... (full server path)

### Server Endpoints:
- POST /api/upload-custody-invoice — multer upload to client folder under "فواتير العهدة"
- All custody data synced via localStorage proxy (pm_custody, pm_custody_dist, pm_custody_invoices)

### Permissions:
- page_custody, cust_receive, cust_distribute, cust_invoice, cust_shared_invoice, cust_accounts, cust_transfer, cust_delete

**Why:** User needs full petty cash management with multi-level distribution and per-invoice settlement.
**How to apply:** Any changes to custody logic must respect the transfer hierarchy and admin-only settlement rule.
