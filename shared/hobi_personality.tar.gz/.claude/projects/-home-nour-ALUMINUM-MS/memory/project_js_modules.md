---
name: JS Modules Detail
description: Detailed summary of all 15 JavaScript modules in pm_server/public/js/ with functions and business logic
type: project
---

# JS Modules Summary

## 00-i18n.js - Internationalization
- 1091-entry Arabic→English dictionary (`_dictArToEn`)
- Auto-reverse dictionary (`_dictEnToAr`)
- Arabic transliteration system (`_arToLatinMap`)
- Key functions: `t(key)`, `switchLang(newLang)`, `_translateAllText()`, `_restoreArabic()`, `_transliterate(text)`
- Auto-runs translation engine every 500ms for 15s on page load if not Arabic

## 01-config.js - Configuration & Constants (VERY LARGE)
- `LOGOS`: Base64 logos for 4 companies (sultan, metal, rajhi, fozan)
- `DEFAULT_STAGES`: 21 production stages with percentages
- `DEFAULT_COLUMNS`: 22 column definitions (id, label, type, show, required)
- `DEFAULT_HOLIDAYS`: Eid, National Day, Foundation Day dates
- `DEFAULT_GALLERIES`: 9 galleries (showrooms)
- `DEFAULT_COMPANIES`: 4 companies (السلطان, عالم المعادن, الراجحي, الفوزان)
- `DEFAULT_REGIONS`: 4 regions (الوسطى, الغربية, الشرقية, الشمالية)
- `DEFAULT_STATUSES`: 9 statuses
- Server sync: localStorage proxy intercepts get/set/remove for `pm_*` keys, debounced 200ms flush to server
- `calcStatusFromStage(stageName)`: Auto-calculates status from stage
- Seed data loader from HTML-embedded JSON

## 02-storage.js - Data Layer
- `loadDataAsync()` / `loadData()`: Server-first with localStorage fallback
- `saveData()`: Save to localStorage + sync to server
- `refreshData()`: Pull from server and re-render all sections
- `exportAllData()` / `importAllData()`: JSON backup/restore with atomic import
- `saveToFile()` / `restoreFromFile()`: HTML file save/restore (embeds data in HTML)
- Navigation: `showPage(pg)` with permission checks
- Auto-backup every 5 minutes

## 03-projects.js - Project Management Core (VERY LARGE)
- `renderStats()`: Dashboard stats with user-level filtering
- `renderTable()`: Project list with search, status, company filters
- `openActionsPanel(id)`: Side panel with 8+ actions
- `editProject(id)` / `saveProject()`: CRUD with auto-status, client folder creation
- `deleteProject(id)`: Remove project + optional folder deletion
- `changeStage(id)`: Stage change with auto-progress calculation
- `openProjectFiles(id)`: File manager (upload, download, preview)
- Smart delivery date calc (approval/site-ready + duration - weekends)
- Pending project review workflow for technicians

## 04-documents.js - Document Generator
- 7 document types: client report, extract, manufacturing form, PO, stages, timeline, measurements
- `previewDoc()` / `printDoc()` / `printAllDocs()`
- Letterhead with company logos, watermark support
- RTL print layout, color-coded phases

## 05-reports.js - Analytics
- `renderReports()`: Multi-perspective analytics with Chart.js
- `openProductionReport()`: Monthly production tracking with delta calculations
- `openMaterialsReport()`: Materials requirement list with Excel export
- Period filtering: all-time, monthly, weekly

## 06-saved.js - Report Archive + Excel Import/Export
- Save/view/print/export production, materials, weekly reports (max 50 each)
- `importExcel()`: Smart column mapping with keyword detection
- `exportProjectsExcel()`: Full Excel export with formatting

## 07-measurements.js - Technical Dimensions
- Per-project measurements: code, section, width(mm), height(mm), area(m²), notes
- CRUD operations, area auto-calculation
- Integration with extract documents

## 08-settings.js - System Administration
- 50+ granular permissions organized by category
- 6 role templates: view, technician, sales, supervisor, accountant, admin
- User CRUD with company/region/gallery filters
- Master password, session duration config
- Watermark controls per user

## 09-demo.js - Sample Data (disabled)

## 10-auth.js - Authentication
- Username/password login (base64 encoded passwords)
- Admin vs regular user flow
- Session management via sessionStorage
- Master password with optional expiry timer
- `_doAuthCheck()`: Init check on page load

## 11-forms.js - Manufacturing Form Builder
- Tabbed editor: aluminum, accessories, installation, study
- Auto-builds from price list, preserves manual edits
- Weight/cost calculations from kg/m rates
- Profit breakdown with admin/sales/company percentages

## 11-forms.js - Added RAL Catalog
- Added full RAL color catalog (_fdFullRAL) with 200+ colors and hex values
- RAL grid in settings with search by code/name, select all/deselect
- Color swatch preview next to aluminum color dropdown in project form
- _fdGetRalHex() extracts hex from color name for preview

## 12-form-types.js - Section Types & Catalogs
- Window type definitions (slider, casement, etc.)
- Supplier catalog management with part codes
- Section images (base64 storage)
- Addons: arc, fixed, 4-leaf options
- Bar weight/price calculations

## 13-installations.js - Site Installation Records
- Installation entry CRUD with server sync
- Large measurement table (15+ rows) with photo upload
- Zero-zero mode (-8mm adjustment)
- Confirm → transfer to main projects
- Merge entries, PDF export

## 14-draw.js - CAD Drawing Module
- Canvas-based window/door designer
- Profile system (PRD, SG50, custom)
- Glass types: single, double, triple, laminate
- RAL color palette
- Panel division with constraint solver
- Interactive dimension editing (click, drag, hover)
- T-bar dragging, zoom, pan
