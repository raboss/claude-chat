---
name: NourWork Architecture Decision
description: Critical architecture - Ra Workshop integration as نور ورك (NourWork) inside NourMetal with thin-client model
type: project
---

## القرار المعماري النهائي (2026-04-06)

البرنامج الجديد اسمه: **"نور ورك" (NourWork)**
(تجنّب اسم Ra Workshop لأسباب قانونية)

## المعمارية:

```
محمود (Windows PC)
  └─▶ Ra.exe (نسخة FOREVER) — يصمم النوافذ
        └─▶ يكتب على SQL Server على جهاز نور

جهاز نور (Linux)
  ├─▶ SQL Server 2022 Docker (RaConfig, RaMaterials, RaProjects)
  └─▶ pm_server (Node.js) — يضيف API endpoints جديدة لقراءة من SQL

موظفين (موبايل/تابلت/PC)
  └─▶ NourMetal Web فقط — بدون أي تنصيب
        └─▶ يشوفوا ورشة نور حسب صلاحياتهم
```

## الفلسفة:
- محمود فقط عنده Ra.exe (حماية البرنامج المكسور)
- الموظفين بس "viewers" عبر web
- كل وصول مقفّل بالصلاحيات
- بدون VPN، بدون Tailscale، بدون ZeroTier للموظفين
- الاتصال للموظفين عبر NourMetal الموجود

## الصلاحيات الجديدة (17):
- page_ra
- ra_tab_projects, ra_tab_windows, ra_tab_status, ra_tab_clients
- ra_view_prices, ra_view_materials, ra_view_dimensions, ra_view_drawings, ra_view_all_clients
- ra_edit_status, ra_add_note, ra_assign_team, ra_mark_delivered
- ra_rpt_summary, ra_rpt_export_pdf, ra_rpt_export_excel

تتفعّل page_ra تلقائياً إذا المستخدم عنده أي صلاحية ra_*

## SQL Server على Docker:
- Image: mcr.microsoft.com/mssql/server:2022-latest (2.27GB)
- Container name: ra-sqlserver
- Port: 1433
- SA Password: NourRa2026!Strong#Pass
- Volume: /home/nour/ALUMINUM-MS/raworkshop_sqldata/
- Databases: RaConfig, RaMaterials, RaProjects
- User: RaUser

## ملف البرنامج:
- /home/nour/ALUMINUM-MS/raworkshop_portable/Ra/ (مفكوك من Ra Workshop FOREVER.rar)
- WindowInfo.dll = FOREVER patched (b915f25b16183fce1e398df530e4fcd3)

## Why:
محمود قرر هاد الأسلوب لـ:
1. حماية البرنامج المكسور من التسريب
2. حماية بيانات الزبائن
3. تجنب توزيع برنامج ثقيل على كل موظف
4. تجنب مشاركة حساب Tailscale الشخصي
5. الموظفين أصلاً يستخدموا NourMetal Web — أبسط لهم

## How to apply:
عند العمل على نور ورك:
- لا توزّع Ra.exe على أي موظف
- كل ميزة جديدة لازم تتربط بصلاحية في nourmetal permissions system
- API endpoints الجديدة بـ pm_server تستخدم npm package: mssql
- اسم البرنامج بالواجهة: "نور ورك" دائماً (مش Ra Workshop ولا ورشة نور)
