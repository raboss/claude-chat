---
name: Business Logic & Data Flow
description: Key business workflows, data structures, API endpoints, and data flow in ALUMINOR
type: project
---

# Business Logic

## 4 Companies
السلطان (Sultan), عالم المعادن (Metal World), الراجحي (Rajhi), الفوزان (Fozan)

## 4 Regions
الوسطى, الغربية, الشرقية, الشمالية

## 9 Galleries (Showrooms)
معرض الرياض, جدة, الدمام, الخبر, التخصصي 1, التخصصي 2, الياسمين, مكه, المبيعات الخارجية

## 21 Production Stages
Contract Signing → Operation Order → Site Readiness → Measurement → Plans → Plans Approval → Project Study → Material Request → Material Painting → Manufacturing Start → Extract Issuance → Second Payment → Installation Order → Aluminum Work Delivery → Installation Start → Glass Request → Glass Delivery → Glass Installation → Site Finishing → Work Testing → Site Delivery

## 9 Project Statuses
توقيع العقد, جاري, تأخير من العميل, تأخير من الشركة, تركيب, موقوف - انتظار سداد العميل, موقوف, تم التسليم, ملغى

## Key Workflows
1. **Project Lifecycle**: Create → Measurements → Documents → Manufacturing → Installation → Delivery
2. **Installation Flow**: Tech adds client → enters measurements with photos → supervisor reviews → confirm → transfer to projects
3. **Document Generation**: Select project → choose doc type → preview → print (with watermark/logo)
4. **Reporting**: Dashboard stats → period filtering → production tracking → materials management

## Data Storage
- Server: JSON files in `data/` dir, each key = `pm_*.json`
- Client: localStorage with `pm_*` prefix
- Sync: localStorage proxy intercepts all pm_* operations, debounced 200ms flush to server
- Fallback: If server unavailable, localStorage only

## API Endpoints
- `GET/POST /api/data/:key` - Single key CRUD
- `POST /api/data-all` - Batch save
- `GET /api/export` / `POST /api/import` - Backup
- `POST /api/client-folder` - Create client folder
- `GET /api/client-files` - List files
- `POST /api/upload-file` / `POST /api/upload-site-photo` - Upload
- `GET /api/file` / `DELETE /api/file` - File operations
- `POST /api/open-folder` / `POST /api/delete-folder` - Folder operations
- `GET/POST /api/activity` - Activity log

## User Permissions (50+)
- Page access, toolbar buttons, project actions, report types, settings sections, installation features, table columns
- 6 role templates: Admin, Supervisor, Technician, Sales, Accountant, Viewer
- Data filters: company, region, gallery restrictions per user
