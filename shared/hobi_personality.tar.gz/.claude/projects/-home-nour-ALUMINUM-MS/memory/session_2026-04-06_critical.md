---
name: Critical Session State 2026-04-06
description: Emergency session save before server restart - Shihab users + Draw v6 + RA Workshop 2023 decompiled
type: project
---

## CRITICAL BACKUP LOCATIONS (DO NOT LOSE)

### Downloads folder backups:
1. **NourMetal_FullBackup_2026-04-06.tar.gz** (70MB) - Complete program backup
2. **NourMetal_FullBackup_2026-04-06/** (106MB) - Uncompressed backup folder
3. **pm_users_SHIHAB_VERSION_2026-04-06.json** - The Shihab version (2 users) 
4. **جلسة برنامج الالمنيوم 5-4-2026.docx** - Full session log

### Critical paths:
- /home/nour/ALUMINUM-MS/pm_server/ - Live production server
- /home/nour/ALUMINUM-MS/claude2_work/ - Development workspace
- /home/nour/ALUMINUM-MS/raworkshop_2023/ - Decompiled RA Workshop 2023
- /home/nour/ALUMINUM-MS/raworkshop_extracted/ - Decompiled RA Workshop 3.6
- /home/nour/ALUMINUM-MS/romchi_decompiled/ - JADX decompiled Romchi APK

## Active users (Shihab version):
- شهاب الدخيل (68 perms) - createdAt 4/4/2026
- احمد حمدي (70 perms) - createdAt 4/4/2026

## Permissions issue (NOT FIXED):
- loadUsers() reads from localStorage only
- When iPad opens app with old localStorage, it overwrites server via saveUsers()
- Need to fix: loadUsers() should fetch from server first
- File: pm_server/public/js/08-settings.js line 188

## Draw module status: v6 = 107.5KB, 2749 lines
- Section view: profile + bead are SEPARATE pieces (correct)
- 3D view: single connected frame using ExtrudeGeometry with hole
- Library pages with SVG profile thumbnails
- Touch support for iPad (44px buttons, prevent zoom)

## RA Workshop 2023 download:
- URL: https://www.raworkshop.com/Downloads/Ra%20Workshop/Installers/Ra%20Workshop%202023.exe
- Login: m2011-11-11@hotmail.com / U2ga9eQ6wR
- Already extracted at /home/nour/ALUMINUM-MS/raworkshop_2023/

## Why:
Mahmoud is going to develop the program on his end and bring it back. 
Server needs restart so session will end. Everything must be preserved.

## How to apply:
- ALWAYS use /home/nour/Downloads/pm_users_SHIHAB_VERSION_2026-04-06.json as the source of truth
- The OLD 5-user file (pm_users_old_backup_*.json) is JUNK - do not restore it
- Use the .tar.gz backup for full program restoration
