---
name: AI Assistant Feature — OpenClaw مدمج مع البرنامج
description: نسخة OpenClaw per-tenant مربوطة بـ pm_server APIs — العميل يحكي واتس والبوت يشتغل على النظام
type: project
originSessionId: 6ff0aa7c-4db1-4687-9089-0c870604af27
---
# الفكرة
محمود بده يضيف **AI Assistant واتس اب شخصي** كجزء من البرنامج (NourMetal/ALUMINOR) —
كل عميل يشتري البرنامج يجيه معه بوت واتس مربوط بحسابه، يقدر يحكي معه:
- "شو مستحقات أبو علي؟"
- "أضف فاتورة جديدة للعميل س بقيمة X"
- "اطلع تقرير المبيعات لهاد الأسبوع"
والبوت يعمل العملية تلقائياً على البرنامج ويرد.

# الوضع الحالي (2026-04-19)
- OpenClaw شغّال كـ container واحد على جهاز نور (image: ghcr.io/openclaw/openclaw:2026.2.24)
- متصل برقم 966580444451
- Tools حالية: excel_tool.py, router.py, web_search.py, tts.py (في /home/nour/nour/)
- يستخدم `docker exec openclaw npx openclaw message send` للإشعارات

# المعمارية المطلوبة (Future)

## 1. Multi-tenant deployment
- كل عميل = container OpenClaw منفصل + volume منفصل + رقم واتس مختلف
- Naming: `openclaw-<tenant_id>` + volume `<tenant_id>_openclaw_data`

## 2. Tools layer جديدة (pm_server_tools.py)
ربط البوت بـ pm_server APIs:
- `get_client_dues(name)` — مستحقات عميل
- `add_invoice(client_id, amount, ...)` — فاتورة جديدة
- `inventory_check(product)` — فحص مخزون
- `sales_report(period)` — تقرير مبيعات
- `add_client(name, phone, ...)` — إضافة عميل
- ... كل endpoint بالـ pm_server يصير tool

## 3. Authentication per tenant
- كل رقم واتس مربوط بـ user في pm_server
- JWT/token يمرّر مع كل API call
- صلاحيات المستخدم = صلاحيات البوت

## 4. Deployment template
سكريبت واحد ينشر stack كامل لعميل جديد:
- pm_server instance (port مختلف)
- SQL Docker volume خاص
- openclaw container + volume
- ربط الـ router بالـ pm_server الخاص

## 5. نسخة تجريبية ثانية (خطوة أولى)
قبل multi-tenant، نعمل نسخة ثانية على جهاز نور:
- container `openclaw2` بنفس الـ image
- volume `nour_openclaw2_data` (رقم واتس ثاني)
- tools في `/home/nour/nour2/` للتعديل بحرية
- تكون sandbox للتطوير

# الفوائد
- ميزة تنافسية ضخمة — ERP + AI assistant في حزمة واحدة
- العميل ما يحتاج يدخل على web/mobile — واتس كافي
- reporting/queries سريعة جداً بدون تدريب

# Why
محمود طلب الفكرة 2026-04-19 ونبّه إنها للتطوير المستقبلي (مش هلق).

# How to apply
- ما نبدأ التطبيق إلا بإذنه
- لما يقول "بلّش" → نبدأ بنسخة ثانية تجريبية (Phase 0)
- بعدها tools layer (Phase 1) ثم deployment template (Phase 2)
