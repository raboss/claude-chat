---
name: Samsung 990 Pro 2TB — سكريبت التركيب
description: سكريبت تفاعلي آمن لتركيب SSD جديد + نقل /mnt/vmstorage — جاهز قبل يوم 20 أبريل
type: project
originSessionId: 6ff0aa7c-4db1-4687-9089-0c870604af27
---
# Samsung 990 Pro 2TB Install

## الحالة
- SSD وصل 2026-04-19 مساءً
- محمود بيركّبه 2026-04-20 بالمكتب

## السكريبت الجاهز
`/home/nour/bin/install-ssd.sh` (executable)

**التشغيل:** `sudo install-ssd.sh`

## المنطق
1. يكتشف القرص الجديد تلقائياً (Samsung 990 أو أي nvme غير nvme0n1)
2. تأكيد مطلوب قبل أي destructive operation
3. GPT + partition واحدة + ext4 + label `vmstorage`
4. rsync /mnt/vmstorage → /mnt/ssd_new (بدون حذف المصدر)
5. تأكيد ثاني بعد التحقق من الأحجام
6. إيقاف VMs + تبديل fstab (مع backup)
7. mount الجديد على /mnt/vmstorage

## الحالة الحالية (قبل التركيب)
- nvme0n1 (Micron 1TB): / (741 GB) + /mnt/vmstorage (194 GB, Used 91 GB)
- /mnt/vmstorage فيه: Rabos.qcow2 (84 GB)

## الخطوات اليدوية بعد السكريبت
- `virsh start rabos-1`
- `qemu-img resize /mnt/vmstorage/Rabos.qcow2 +200G`
- داخل Windows: Disk Management → Extend Volume

## Why
محمود طلب خطة جاهزة قبل ما يروح المكتب. السكريبت موجود في /home/nour/bin/ (PATH).

## How to apply
إذا محمود رجع من المكتب وقال SSD مركّب → وجّهه لـ `sudo install-ssd.sh`.
