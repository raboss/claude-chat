---
name: hobi / wadi launcher scripts
description: سكربتات فتح جلسات حوبي ووديع — كل وحدة تفتح gnome-terminal جديد + استرجاع ذاكرة كاملة + آخر 3 رسائل
type: reference
originSessionId: 16806894-a10c-4d5b-925a-8151bb900b57
---
# hobi / wadi — launcher scripts

## البنية (من 2026-04-19)

```
/home/nour/bin/hobi                      # executable — يفتح حوبي (ALUMINOR)
/home/nour/bin/wadi                      # executable — يفتح وديع (NOUR + live_memory)
/home/nour/bin/prompts/hobi_prompt.txt   # prompt كامل لحوبي
/home/nour/bin/prompts/wadi_prompt.txt   # prompt كامل لوديع
/home/nour/سطح المكتب/المنيوم.desktop    # Exec=/home/nour/bin/hobi
/home/nour/سطح المكتب/وديع.desktop       # Exec=/home/nour/bin/wadi
```

## السلوك
- كل سكربت يفتح **gnome-terminal جديد** (الترمينال الأساسي) — ما بيلمس أي جلسة/ترمينال ثاني
- `extract_last_instructions.py` بيستخرج آخر 3 رسائل من محمود → `LAST_INSTRUCTIONS_*.md`
- claude بيتشغّل مع prompt بياخده من ملف (ما في quoting issues)
- الـ prompt يأمر claude:
  1. Glob على `memory/*.md` + قراءة كل ملف (مش بس اللي في MEMORY.md)
  2. قراءة `session_live.md` + `QUICK_RECALL.md` (وديع)
  3. قراءة `LAST_INSTRUCTIONS_*.md` (آخر 3 رسائل)
  4. ملخّص سطرين + استكمال فوري بدون سؤال

## قرارات مهمة (من تجارب فشلت)
- ❌ لا `setsid` / `disown` / redirect stdin/stdout → بيخرّبوا gnome-terminal
- ❌ لا `start_services.sh` داخل `wadi` → بيعمل `pkill` وكان بيقتل جلسات موجودة
- ❌ لا prompt مباشر في bash -lc → quoting مع عربي بيتكسر
- ✅ gnome-terminal لحاله (dbus client) — بيرجع فوراً بدون أي flags
- ✅ live_memory بـ `pgrep ||` فقط — ما بيقتل ثم يشغّل

## الاستخدام
- من أي ترمينال: `hobi` أو `wadi`
- من سطح المكتب: دبل-كلك `المنيوم` أو `وديع`

## مسارات الكلودين
- **حوبي** (ALUMINUM-MS): `/home/nour/ALUMINUM-MS` → `~/.claude/projects/-home-nour-ALUMINUM-MS/`
- **وديع** (الأساسي): `/home/nour/nour` → `~/.claude/projects/-home-nour-nour/`

## ما عاد موجود
- ~~`/home/nour/bin/switch-to-wadi.sh`~~ (انحذف)
- ~~`wadi` / `hobi-back` / `wadi-new` aliases في .bashrc~~ (انحذفوا)
- ~~`/home/nour/nour/resume_session.sh`~~ + ~~`open_aluminum.sh`~~ (انحذفوا)
- ~~`/home/nour/bin/claude-hobi`~~ + ~~`claude-main`~~ (انحذفوا)
