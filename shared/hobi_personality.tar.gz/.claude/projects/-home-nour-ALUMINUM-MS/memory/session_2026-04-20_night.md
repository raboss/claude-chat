---
name: جلسة ليلة 20 أبريل — معركة Multi-User Ra Workshop
description: محاولات تشغيل Ra multi-user، انتهت بـ RDP Wrapper + dual session test جاهز للصباح
type: project
originSessionId: 66234412-84da-4ebc-80f9-811f6a812f69
---
# ليلة 20 أبريل — البحث عن حل multi-user

## 🎯 الهدف
محمود يريد 50 موظف يستخدمون Ra Workshop متوازياً.

## 🔴 الاكتشافات الحاسمة

### 1. Ra.exe **single-instance per session**
- `fSingleSessionPerUser = 0` (multi-user مسموح)
- لكن إطلاق Ra.exe ثاني من نفس session → **Windows يرفض بصمت**
- المحاولة: PID 5876 بقي وحيد، Ra.exe ثاني ما ظهر

### 2. Ra.exe **Obfuscated (ObfuscationAttribute)**
- `AssemblyTitle = "RaWorkshop" v4.1.0.0`
- أسماء الـ classes مبهمة → decompile صعب
- 4 GUIDs في الـ binary (أحدها قد يكون Mutex name):
  - `04B79346-721A-4FBB-93F8-88C5405ACD94`
  - `3832D640-CF90-11CF-8E43-00A0C911005A` (DevExpress)
  - `AC36B093-1842-4D87-BC29-E792310FC9D3`
  - `F7904448-0E53-4C3E-B4F8-3898A580C342`

### 3. Procmon capture (50 MB) = Mutex operations **غير مسجلة** افتراضياً
- handle.exe سيبين بعد تشغيل Ra

## ✅ الإنجازات الليلية

### Guacamole Multi-Connection
- `/opt/guacamole/home/user-mapping.xml` الآن فيه **2 connections**:
  - `rabos-session1` (RaBoS / Mhmoud@123)
  - `user2-session2` (User2 / User2Pass!)

### User2 أُنشئ على VM
- WinRM: `RaBoS` / `1559` (القديمة، تبقى للـ WinRM)
- Windows login: `Mhmoud@123` (الجديدة، غيّرها محمود)
- User2 محمّل في Users + Remote Desktop Users

### RDP Wrapper مُركّب ✅
- Windows build 26200.8246 (Windows 11 24H2)
- termsrv.dll: 10.0.26100.8115
- rdpwrap.dll registered
- ini محدّث من sebaxakerhtc/rdpwrap.ini
- TermService: Running
- **نظرياً:** multi-session RDP ممكن الآن

### nourwork-designer.html — Dual Session Test ✅
- `https://aluminum-nour.ngrok.pro/unified/nourwork-designer.html`
- زر **"🧪 اختبار جلستين"** — يفتح Guacamole مرتين جنباً إلى جنب
- Session 1 = RaBoS | Session 2 = User2
- **هذا الاختبار الحاسم** — لو Ra يظهر في الاثنتين = multi-user ممكن

## 🔴 مشكلة متبقية: Ra.exe ما يفتح حالياً

- آخر تشغيل ناجح: PID 5876 @ 9:58 PM (محمود فتحه)
- بعد VM reboot (8 CPU upgrade): Ra.exe لا يبدأ
- LocalDB v16.0.1000.6 موجود وشغّال
- RaServer.exe يبدأ بس يموت
- Ra.log.xml: `System.ObjectDisposedException: Cannot access a disposed object. Object name: 'FrmMain'`
- نفس الخطأ في WIN_03 من عماد

**السبب المحتمل:** user.config جديد بعد reboot/CPU change يحتاج إعادة إعداد.
**الحل المحتمل:** تشغيل Ra من shortcut أو إعادة user.config.

## 📋 للصبح

### 1. اختبار الحاسم (أولوية عالية)
- محمود يفتح `/unified/nourwork-designer.html`
- يضغط **"🧪 اختبار جلستين"**
- يختبر: هل الجلستين تشتغلان معاً؟
- **إذا نعم** → RDP Wrapper يعمل → Multi-user ممكن بـ 50 user
- **إذا لا** → نجرب Sandboxie Plus (يحتاج UAC يدوي)

### 2. إصلاح Ra.exe (إذا لم يفتح)
- محاولة: حذف `C:\Users\RaBoS\AppData\Local\Pyramid_Software\` → Ra يعمل fresh
- أو تشغيل Ra.exe من RDP shortcut عادي
- أو تشغيل RaServer.exe + Ra.exe بالترتيب الصحيح

### 3. خطط بديلة لو multi-session فشل
- **Linked Clones:** 14 VM خفيف = 14 user على 62 GB RAM
- **Hybrid:** Ra للمهندسين (1-2) + web للباقين
- **de4dot:** deobfuscate Ra.exe → نعدل Mutex مباشرة

## 🎁 رسائل عماد اللي بعثت
- **#28:** توضيح القصة + Sandboxie + de4dot + Process Monitor
- **#29:** Ra copy على Desktop (محمود حطها يدوياً)

## 📁 ملفات مفيدة
- `/tmp/Ra.exe` (10.8 MB) — نسخة من Ra.exe لتحليل Linux
- `/tmp/Ra.il` (2158 سطر IL) — monodis output جزئي
- `/opt/guacamole/home/user-mapping.xml` — 2 connections
- VM: `C:\Ra-Test\` (نسخة آمنة)
- VM: `C:\dnSpy\` (portable)
- VM: `C:\Handle\` (Sysinternals handle.exe)
- VM: `C:\ProcMon\` (Process Monitor)
- VM: `C:\RDPWrap\` (RDP Wrapper)
- VM: `C:\Program Files\RDP Wrapper\` (مُركّب)

## 💤 محمود نائم
وعده: "بدي أخبار حلوة الصبح" — الأخبار:
1. ✅ RDP Wrapper مُركّب (multi-session نظرياً ممكن)
2. ✅ 2 sessions جاهزة للاختبار
3. ✅ User2 أُنشئ
4. ✅ صفحة dual-test جاهزة
5. ⏳ اختبار فعلي ينتظره
