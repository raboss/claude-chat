---
name: Workflow Preferences
description: Nour's preferences for how to work on this project - ignore backups, save memory frequently
type: feedback
---

- Ignore backup folders (pm_server_backup_*) - don't waste time reading them
- Save session to memory every ~5 minutes to avoid re-reading entire codebase each time
- Android app (pm_android_app) is to be developed later - don't touch it now
- Client files folder (ملفات العملاء) is auto-generated from the project - no direct edits needed
- Focus work on `pm_server/` directory

**Why:** Large codebase with many files. Re-reading wastes time and context.
**How to apply:** Check memory first before reading files. Save progress incrementally.
