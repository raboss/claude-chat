---
name: UPS Tecnoware ERA Plus 2.600 — مراقبة عبر NUT
description: محمود ركّب UPS Tecnoware لحماية جهاز نور من قطع الكهربا. NUT شغّال ويبعت تنبيهات واتساب
type: project
originSessionId: 7ad08dff-979c-4602-999d-5d5338756c90
---
# الإعداد (2026-04-18)

## الجهاز
- **Tecnoware UPS ERA Plus 2.600** (2600VA Line Interactive)
- USB ID: `0001:0000` (chipset MEC0003 — Mecer/Voltronic OEM)
- متصل بجهاز نور عبر USB-B (شكل الطابعة)

## NUT Configuration
- **driver:** `nutdrv_qx`
- **subdriver:** `krauler`
- **protocol:** `q1`
- **langid_fix:** `0x409`
- **battery nominal:** 24V (2×12V)

## الملفات
- `/etc/nut/ups.conf` — UPS named `tecnoware`
- `/etc/nut/upsd.users` — admin/nourups2026 + upsmon/monpass2026
- `/etc/nut/upsmon.conf` — auto-shutdown على LOWBATT
- `/etc/udev/rules.d/52-nut-mecer.rules` — صلاحيات USB لـ 0001:0000
- `/usr/local/bin/ups-notify.sh` — يبعت واتساب لمحمود
- `/var/log/ups-events.log` — سجل الأحداث

## الخدمات (كلها enabled + active)
- nut-server.service
- nut-monitor.service
- nut-driver.target

## الـ Notifications على واتساب
يستخدم `docker exec openclaw npx openclaw message send` **مباشرة** (مش agent!) لرقم `966580444451@s.whatsapp.net`:

⚠️ **مهم:** ما تستخدم `nour-send.sh` للتنبيهات الآلية — هو يشغّل AI agent اللي بيفسّر الرسالة كأمر ويرد بشي مش متوقع. للتنبيهات استخدم `openclaw message send` مباشرة.

- 🔴 ONBATT (الكهربا قطعت)
- 🟢 ONLINE (الكهربا رجعت)
- ⚠️ LOWBATT (البطارية فاضية)
- 🛑 SHUTDOWN (الجهاز يطفي بأمان)

## أوامر مفيدة
```bash
upsc tecnoware@localhost              # كل القيم
upsc tecnoware@localhost battery.charge
upsc tecnoware@localhost ups.status   # OL=online, OB=on battery, LB=low
sudo systemctl status nut-monitor
tail -f /var/log/ups-events.log
```

## Why
محمود يقول الكهربا تقطع كثير وVM ويندوز ما تشتغل لحالها بعد القطع.
الحل الأساسي = BIOS AC Recovery → Power On (لما الكهربا ترجع).
الحل الثاني = UPS يعطي وقت + auto-shutdown آمن.

## How to apply
- لما تقطع الكهربا، NUT يكتشف خلال 5 ثواني ويبعت واتساب
- لما البطارية تنزل تحت 20% (افتراضي blazer)، الجهاز يطفي بأمان (مع VM)
- لما الكهربا ترجع وUPS يشحن فوق العتبة، الجهاز يفتح (يحتاج BIOS AC Recovery)
