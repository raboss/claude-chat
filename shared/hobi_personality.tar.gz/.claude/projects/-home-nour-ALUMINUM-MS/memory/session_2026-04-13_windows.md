---
name: جلسة 13 أبريل — ويندوز جديد + WinDoorCraft
description: تثبيت ويندوز 11 Pro جديد + تفعيل + RDP + سحب كود WinDoorCraft
type: project
originSessionId: cd70cf0e-6943-4501-a247-05757fa58846
---
## ويندوز 11 Pro — VM Rabos
- ✅ تثبيت نظيف من الصفر (القرص القديم خربت BCD)
- ✅ Windows 11 Pro مفعّل (KMS: kms8.msguides.com)
- ✅ RDP مفعّل عبر socat port forwarding
- ✅ اسم الجهاز: Rabos
- حساب RaBoS (Microsoft account): m2011-11-11@hotmail.com / gubguN-cacjo8-hirvuc / PIN: 5891
- ~~حساب rdp (محلي للريموت): rdp / 1559~~ — محذوف! اليوزر الوحيد هو RaBoS / 1559
- Tailscale IP: 100.66.50.27 (بس RDP يمر عبر نور: 100.104.45.91)
- VM IP: 192.168.122.106 (ممكن يتغيّر بعد ريبوت!)
- RAM: 12GB (من 46GB إجمالي)
- sudo بدون باسوورد: /etc/sudoers.d/nour
- ⚠️ RDP يمر عبر socat: sudo socat TCP-LISTEN:3389,fork,reuseaddr TCP:192.168.122.106:3389 &
- ⚠️ xrdp على الهوست لازم يكون مطفي (يتعارض مع port 3389)
- ⚠️ Firewall مطفي على الويندوز

## البرامج المثبّتة
- ✅ Google Chrome
- ✅ Microsoft 365 (Word, Excel, PowerPoint, Outlook, OneDrive)
- ✅ Adobe Acrobat Reader (64-bit)
- ✅ Tailscale
- ✅ 7-Zip
- ✅ Notepad++
- ✅ VLC

## البرامج المتبقية (بدها تنزيل يدوي + كراك)
- [ ] AutoCAD (مكسور)
- [ ] SketchUp 2022 (مكسور) + إضافات
- [ ] Enscape (مكسور)
- [ ] RA Workshop (مكسور — جاهز عندنا)

## القرص
- القرص القديم + win_repair.iso حُذفوا لتحرير مساحة (149GB)
- qcow2 حالي: ~35GB

## RDP Setup
- iPad يتصل عبر: 100.104.45.91:3389 → socat → 192.168.122.106:3389
- التطبيق: Windows App على iPad
- ⚠️ socat لازم يكون شغّال (مش persistent — بده systemd service)
- ⚠️ xdotool عبر xfreerdp: النقطة (.) بتنكتب كـ (>) — مشكلة keyboard mapping

## WinDoorCraft — منافس صيني
- الموقع: https://ln.windoorcraft.com
- Vue.js + GraphQL + Alibaba Cloud
- سحبنا 97 ملف JS (3.4MB) → /home/nour/windoorcraft/
- ميزاته: رسم 2D + 3D + ريندر + مكتبة نوافذ + طلبات + قياسات
- **الخطة:** نفكّ الكود ونستفيد من الرسم والـ 3D لمشروعنا
- محمود كان مشترك فيه ($700/سنة بس للرسم)
