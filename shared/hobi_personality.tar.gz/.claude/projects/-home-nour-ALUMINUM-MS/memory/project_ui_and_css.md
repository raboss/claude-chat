---
name: UI, CSS, and PWA Details
description: CSS theme, color scheme, PWA config, service worker, and HTML structure details
type: project
---

# UI & Styling

## Color Scheme
- **Dark Mode (Default):** bg #0a0f1e, surface #0f172a, primary #3b82f6, amber #f59e0b, pink #f43f5e, green #10b981, cyan #06b6d4, text #edf2f7
- **Light Mode:** bg #edf0f5, surfaces white, primary #2563eb, text #1a202c
- Glassmorphism effects (backdrop blur, transparency)
- RTL support, Cairo font

## Layout
- Desktop: sidebar + main content
- Mobile: top bar + bottom nav
- Responsive breakpoints for tablet/mobile

## PWA (manifest.json)
- Name: "ALUMINOR - Integrated Solutions"
- Display: standalone, theme #0a1628
- Icons: 192x192, 512x512 (maskable)
- Shortcuts: Projects, Reports, Documents
- Language: Arabic, RTL

## Service Worker (sw.js)
- Cache name: pm-app-v99
- Strategy: Network-first with cache fallback
- Caches all static assets (CSS, JS, HTML, manifest, icons)

## index.html Structure (1471 lines)
- Loading screen with animated progress
- Sidebar: logo, 7 nav buttons, action buttons (save, backup, refresh, logout), language/theme toggles, notifications bell
- Mobile topbar + bottom nav
- Backup popup menu
- Activity panel modal
- 7 page divs (projects, reports, saved, documents, installations, drawings, settings)
- Modals: newProjectModal, timelineModal, loginScreen, translationOverlay, installOverlay
- External libs: XLSX.js, Chart.js
- 15 local JS modules loaded in order (00-14)

## project-report.html
- System documentation report with 10 sections
- Cover page, architecture diagram, module descriptions, permissions, API docs
- Print-optimized A4 layout
