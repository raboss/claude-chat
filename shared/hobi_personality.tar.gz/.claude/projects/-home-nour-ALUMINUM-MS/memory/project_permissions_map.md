---
name: Complete Permissions Map
description: Full map of all 95+ permissions organized by category with descriptions
type: project
---

## جميع الصلاحيات (95+ صلاحية)

### 📄 الصفحات (10)
| المفتاح | الوصف | ملاحظات |
|---|---|---|
| page_projects | المشاريع | الصفحة الرئيسية |
| page_reports | التقارير | |
| page_saved | السجلات | |
| page_documents | المستندات | |
| page_installations | التركيبات | |
| page_drawings | الرسومات | |
| page_hr | الموظفين | تفعّل تلقائي إذا عنده أي صلاحية فرعية |
| page_designs | التصاميم | lazy loaded |
| page_custody | الحسابات | تفعّل تلقائي إذا عنده أي صلاحية فرعية |
| page_settings | الإعدادات | |

### 🔧 شريط الأدوات (12)
toolbar_new, toolbar_import, toolbar_export, toolbar_save, toolbar_prod, toolbar_weekly, toolbar_materials, toolbar_form, toolbar_purchase, toolbar_savefile, toolbar_restore, toolbar_backup

### 🔘 أزرار المشروع (13)
btn_edit, btn_timeline, btn_stage, btn_quick_stage, btn_extract, btn_form, btn_purchase, btn_workorder, btn_files, btn_meas, btn_price, btn_clientreport, btn_delete

### 📊 تبويبات التقارير (5)
rpt_tab_overview, rpt_tab_weekly, rpt_tab_monthly, rpt_tab_client, rpt_tab_timeline

### 📋 أزرار التقارير (6)
rpt_prod, rpt_weekly_new, rpt_mats, rpt_print, rpt_save, rpt_excel

### 💾 السجلات (6)
saved_prod, saved_weekly, saved_mats, saved_view, saved_print, saved_delete

### ⚙️ الإعدادات (12)
set_companies, set_security, set_stages, set_gallery, set_regions, set_columns, set_logos, set_sections, set_users, set_backup, set_holidays, set_formdata

### 👥 الموظفين (11)
| المفتاح | الوصف |
|---|---|
| hr_tab_org | تبويب الهيكل التنظيمي |
| hr_tab_list | تبويب قائمة الموظفين |
| hr_tab_salary | تبويب الرواتب |
| hr_tab_attend | تبويب الحضور والانصراف |
| hr_tab_depts | تبويب إدارة الأقسام |
| hr_tab_vehicles | تبويب المركبات |
| hr_add_emp | إضافة موظف |
| hr_edit_emp | تعديل موظف |
| hr_delete_emp | حذف موظف |
| hr_print | طباعة الهيكل |
| hr_export | تصدير الموظفين |

### 💰 الحسابات (7)
| المفتاح | الوصف | ملاحظات |
|---|---|---|
| cust_receive | استلام عهدة | تبويب استلام العهدة |
| cust_distribute | توزيع عهدة | تبويب توزيع العهدة |
| cust_invoice | إضافة فاتورة | زر إضافة فاتورة |
| cust_shared_invoice | فاتورة مشتركة | زر فاتورة مشتركة |
| cust_accounts | حسابات الموظفين | تبويب حسابات الموظفين |
| cust_transfer | تحويل عهدة | زر تحويل لموظف آخر |
| cust_delete | حذف (عهدة) | حذف عهدة/توزيع/فاتورة |

### 🎨 التصاميم (3)
ds_import_dxf, ds_view_3d, ds_add_profile

### 🔨 التركيبات (27+)
inst_add_client, inst_add_defect, inst_maint_new, inst_maint_view, inst_maint_complete, inst_maint_print, inst_maint_edit, inst_maint_delete, inst_confirm, inst_merge, inst_delete, inst_delete_meas, inst_pdf, inst_delivery_new, inst_delivery_view, inst_delivery_print, inst_delivery_upload, inst_delivery_complete, inst_delivery_delete, inst_defect_confirm, inst_defect_delete, inst_defect_pdf, inst_measorder_new, inst_measorder_view, inst_measorder_complete, inst_measorder_delete, inst_team_tab, inst_team_add, inst_team_edit, inst_team_delete, inst_team_add_project, inst_team_remove_project, inst_team_workers, inst_team_save_history, inst_team_print, inst_history_tab, inst_history_delete, inst_history_print

### أخرى (2)
btn_spacecraft, btn_refresh

## التفعيل التلقائي (_PAGE_SUB_PERMS)
إذا المستخدم عنده أي صلاحية فرعية، الصفحة الرئيسية تتفعّل تلقائي:
- page_hr ← أي hr_* صلاحية
- page_designs ← أي ds_* صلاحية
- page_custody ← أي cust_* صلاحية
- page_installations ← أي inst_* صلاحية

## أمثلة للأدوار:
- **فني تركيبات**: page_installations + inst_add_client + inst_maint_complete + cust_invoice + cust_accounts
- **محاسب**: page_projects + page_reports + page_custody + cust_receive + cust_distribute + cust_invoice + cust_accounts
- **مشرف**: كل شي ما عدا btn_delete + page_settings + set_users + set_security + set_backup

**Why:** Reference for setting up user permissions correctly
**How to apply:** Use when creating new users or adjusting roles
