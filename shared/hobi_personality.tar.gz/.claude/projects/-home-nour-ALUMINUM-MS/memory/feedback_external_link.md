---
name: دايماً الرابط الخارجي
description: محمود يشتغل من الآيباد — دايماً أعطيه الرابط الخارجي مش localhost
type: feedback
originSessionId: 4de4806b-129d-4ae1-b554-d6b1f5854c2a
---
دايماً أعطي محمود الرابط الخارجي: `https://aluminum-nour.ngrok.pro`
**Why:** محمود بيشتغل من الآيباد عبر Blink Shell — localhost ما بيوصلو
**How to apply:** أي رابط للبرنامج = الرابط الخارجي. ما تحط localhost أبداً.
