---
name: إعدادات الشبكة — failover WiFi/Ethernet
description: حل انقطاع RDP/AnyDesk — Ethernet primary + WiFi backup تلقائي
type: project
originSessionId: d294f395-d82c-4ddc-aba7-e355afaaebd4
---
# إعدادات الشبكة على اللابتوب

## الواجهات
- **enp0s31f6** (Ethernet): 192.168.8.16/24 → gateway 192.168.8.1 — metric 100 (primary)
- **wlp0s20f3** (WiFi "5G"): 192.168.0.198/24 → gateway 192.168.0.1 — metric 21000 (backup)
- **tailscale0**: 100.104.45.91/32 — ما يتدخل بالـ default routing
- **virbr0**: 192.168.122.1/24 — VM internal
- **docker0 + br-***: Docker networks

## القاعدة الذهبية
- Ethernet أولوية أعلى (metric أقل) → دائماً المفضّل
- WiFi backup تلقائي → ينشط فقط لو Ethernet فصل
- Failover خلال 2-5 ثواني

## الأمر المستخدم (19 أبريل)
```bash
sudo nmcli con mod "5G" ipv4.route-metric 1000 ipv6.route-metric 1000 ipv4.dns-priority 200
sudo nmcli con down "5G" && sudo nmcli con up "5G"
```
ملاحظة: NM بيضيف offset ~20000 لـ WiFi فطلع metric فعلي 21000

## أعراض قبل الإصلاح (سجل)
- RDP/AnyDesk يفصلوا ويرجعوا وحدهم
- ping Ethernet: 83ms ± 4ms (ممتاز)
- ping WiFi "5G": 75-223ms mdev 50ms (jitter عالي كارثي)
- DHCP renewal على Ethernet كل 27-30 دقيقة (من إعدادات الراوتر)

## TODO لاحقاً
- زيادة DHCP lease time من واجهة الراوتر 192.168.8.1 → 24 ساعة
- إذا WiFi "5G" ضل بـ jitter عالي بعد انتقال لشبكة ثانية، فحص قناة 5GHz
