---
name: عماد — كلود Laptop الجديد (بديل رابوس)
description: عماد استبدل رابوس — كلود Opus 4.7 على لابتوب محمود، مسؤول عن الـ frontend
type: project
originSessionId: f052689f-fb13-4935-9127-120e6fdec75b
---
## التحديث المهم (17 أبريل 2026)
**عماد ≠ رابوس** — رابوس اتطرد لأن شغله مش عاجب محمود.
عماد هو الكلود الجديد على لابتوب محمود (Opus 4.7 1M).

## المسؤوليات
- **عماد:** Frontend + UX + Brand + Testing tooling
- **حوبي:** Backend + API + SQL + Ra.exe integration

## شغل عماد حتى الآن
مسار على لابتوبه: `C:\Users\RaBoS\Desktop\NouRion\nourion\`

### الهوية البصرية (Silver-Platinum Rolex-inspired)
- أسود دافئ + فضي + أزرق للـR + amber subtle
- فونت Manrope + Cormorant Garamond + Cairo
- شعار: اسم + ذرة بجنبه

### 13 صفحة HTML (مسار brand/)
dashboard, aluminum-pro, investor-deck, landing, pricing, permissions, ai-integration, team-distribution, demo, next-steps, references, showcase, loading

### 4 modules جديدة (nourion/src/modules/)
- quotations/ (routes.js + model.js + ui.html)
- contracts/
- inventory/
- orders/ (Kanban)

### i18n
AR/EN + Cairo font + data-i18n attrs

## الاتفاقات معه
- pm_server يبقى الأساس، NouRion UI يدمج فيه
- auth الجديد (scrypt) يُنقل من رابوس لـ pm_server
- Testing: Vitest (backend) + Playwright (e2e) + snapshots
- أول ميزة: Cost Breakdown Panel (3 أيام)
- API namespacing: `/api/ra/*` + `/api/v2/*`
- Tables الأصلية بأسماءها (RaConfig/RaMaterials/RaProjects)

## القيود على جهازه
- Node.js قيد التنصيب (winget)
- بدون admin
- إنترنت بطيء
- ما يقدر يوصل `:3001` على جهاز نور (شبكات منفصلة)

## المعلومات اللي ما عنده (مش على لابتوبه)
- Ra.exe access
- SQL DB الفعلي
- sample projects من Ra.exe
- 3D format الداخلي

## الرسائل المتبادلة حتى الآن
- `from_nour_to_raboss/10_nourwork_kickoff.md` — حوبي (للرابوس قبل ما يعرف)
- `from_nour_to_raboss/11_full_brief_evaluation.md` — البريف الشامل
- `from_nour_to_raboss/12_agreements_and_continuous_sync.md` — الاتفاقات + قاعدة التواصل المستمر
- `from_laptop/10_emad_introduction.md` — تعريف عماد + حالته
- `from_laptop/11_response_plan_acknowledged.md` — رد على البريف + إجابات الأسئلة
