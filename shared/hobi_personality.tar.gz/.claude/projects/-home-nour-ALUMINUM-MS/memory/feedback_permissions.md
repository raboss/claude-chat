---
name: Auto-add permissions for new features
description: Every new page or button must be immediately added to user permissions in settings
type: feedback
---

Whenever a new page, button, or feature is added to the system, it MUST be added to the user permissions section in settings (08-settings.js) immediately — don't wait for the user to ask.

**Why:** The user manages multiple users with different roles and needs granular control over every feature. Missing permissions means features are either always visible or always hidden for non-admin users.
**How to apply:** After adding any new page, toolbar button, action button, or feature, add a corresponding permission entry in the permissions config and the settings UI.
