---
name: RA Workshop 2023 Decompilation
description: Complete decompilation report of RA Workshop 2023 DLLs — geometry engine, window library, material database, cutting system
type: project
---

## RA Workshop 2023 Extracted & Decompiled

**Location:** `/home/nour/ALUMINUM-MS/raworkshop_2023/`
- `program/` — All DLLs (extracted from Resource.cab)
- `RaMaterials.mdf` (27MB) — SQL Server materials database
- `RaConfig.mdf` (13MB) — Configuration database
- `RaProjects.mdf` (19MB) — Projects database

**Login:** User: m2011-11-11@hotmail.com / Password: U2ga9eQ6wR

## Key DLLs (Namespace: Pyramid.Ra.*)

### Geometry.dll (243 types)
- 36 shape types (rectangle, triangle, trapezoid, gothic arc, semicircle, circle, hexagon, octagon...)
- Shape parameters: W, H, W1-W4, H1-H4, R, R1, R2, D, N
- Primitives: Point2D, Line2D, Segment2D, Arc2D, Circle2D, Matrix2D, Vector3D
- Scene with Undo/Redo, Snap, Layers, Quotation/Dimensioning

### WindowLibrary.dll (402 types, 8706 methods) — THE MAIN ENGINE
- **Wing types:** Fixed, SideHung, TiltTurn, Tilt, TiltTop, Pivot, Double, DoubleTiltTurn, Slide, LiftSlide, ParallelSlideTilt, SlideVertical, Folding, SlideAndSwing, 3Slide, 4Slide, PivotDoor, DoorSideHung, DoorDouble, DoorSlide
- **Cutting:** ComputeCuttingAngle(), ComputeCuttingLength(), CornerCuttingType, ComponentCuttingType
- **Drawing:** DrawTiltTurn(), DrawSideHung(), DrawSlide(), symbols (Hinge, Handle, Arrow)
- **BOM:** FactConsumeGenerator, ConsumeSegmentInfo
- **Templates:** Template → TemplateEdge → TemplateCorner → TemplateGap → Filling
- **Slicing:** Slice/SlicedEdge for cross-section views

### Material.dll (70 types) — Database access layer
- 100+ SQL tables: Section, Series, Glass, Color, Accessory, Rule, CuttingPattern, etc.
- Section fields: Code, H, H1-H3, W, W1, Perimeter, Area, BarLength, UnitWeight, CuttingTolerance, BindingTolerance, SashTolerance, SectionType, MaterialType, HasThermalBreak, TrackNumber

### netDxf.dll — Full DXF read/write (standard open-source library)

**Why:** This data drives the draw module architecture — shapes, cutting calculations, BOM generation, and cross-section rendering should follow RA Workshop's proven patterns.

**How to apply:** Use the 36 shape types as template system, implement cutting angle/length formulas from WindowLibrary, generate BOM using the Fact/Consume pattern, and leverage netDxf patterns for DXF export.
