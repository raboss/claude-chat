# NouRion — Designer Brief

## 📋 ملخص المشروع (Project Summary)

**Brand Name:** NouRion
**Industry:** SaaS Manufacturing Platform (B2B)
**Target Audience:** Aluminum, Steel, Wood, UPVC factories — Middle East
**Tagline:** Intelligent Manufacturing Platform
**Languages:** Arabic (RTL), English, Hindi

---

## 🎨 Brand Identity (موجود فعلاً)

### Colors
- **Primary Navy:** `#1E5FA8`
- **Sky Blue:** `#3FA2E0`
- **Amber Accent:** `#F4A91E`
- **Coral/Red:** `#E63946`
- **Cosmos Dark:** `#0A1628`
- **White:** `#FFFFFF`

### Typography
- **Manrope** (English/numbers)
- **Cairo** (Arabic)

### Logo Concept
شعار NouRion = اسم + ذرة (atom symbol) — يرمز للذكاء الاصطناعي والدقة العلمية.
*(الشعار جاهز — مرفق `logo-correct.webp`)*

---

## 🎯 المطلوب (Deliverables)

### Icon Set: 60 أيقونة بنفس الستايل

#### Style Direction
- **Style:** Duotone OR Filled-3D OR Glassmorphism — اختار واحد
- **Format:** SVG (vector)
- **Size:** 24×24, 32×32, 48×48 (3 أحجام لكل أيقونة)
- **Reference styles:**
  - Phosphor Icons (https://phosphoricons.com)
  - Streamline Icons (https://streamlinehq.com)
  - Tabler Icons (https://tabler.io/icons)
- **Mood:** Modern, technical, professional — مش cute أو playful

#### Color Variants
كل أيقونة لازم تجي بـ 4 ألوان من الـ palette فوق + monochrome (للخلفيات)

#### قائمة الأيقونات المطلوبة (60 icon)

##### 🏗️ Manufacturing & Projects (15)
1. Project / Folder
2. Quotation / Document
3. Contract / Signed paper
4. Measurement / Ruler
5. Design / Pencil + ruler
6. Manufacturing order
7. Cut order / Saw
8. Glass order / Window
9. Assembly / Gears
10. Aluminum profile
11. Frame / Window frame
12. Door
13. Curtain wall
14. Railing
15. Project status / Timeline

##### 📦 Inventory & Supply (10)
16. Inventory / Boxes stack
17. Warehouse / Building with boxes
18. Material request (MR)
19. Issuance note / Outgoing arrow
20. Stock level / Bar chart
21. Reorder alert / Bell
22. Supplier / Truck
23. Receipt / Receipt paper
24. Item / Single box
25. Movement / Arrows transfer

##### 👥 People & HR (10)
26. Employee / Person
27. Team / Group
28. Department / Organization tree
29. Salary / Money
30. Attendance / Calendar check
31. Vehicle / Car
32. Driver / ID badge
33. Org chart / Hierarchy
34. Permissions / Shield with lock
35. Roles / Star badge

##### 💰 Financial (10)
36. Custody / Wallet
37. Invoice / Bill
38. Payment / Credit card
39. Extract / Receipt
40. Down payment
41. Revenue / Chart up
42. Expense / Chart down
43. VAT / Percent
44. Currency / SAR symbol
45. Bank transfer

##### 📊 Reports & Analytics (8)
46. Dashboard
47. Bar chart
48. Line chart
49. Pie chart
50. KPI / Speedometer
51. Export / Download
52. Print
53. Share

##### ⚙️ System (7)
54. Settings / Gear
55. Notification / Bell
56. Search
57. Filter
58. Add (+)
59. Edit / Pencil
60. Delete / Trash

---

## 📐 Specifications (المواصفات الفنية)

### File Format
- **Master:** Figma file with all icons organized in pages
- **Export:** SVG (clean, no inline styles, < 2KB each)
- **Naming:** `nourion-icon-{name}-{variant}.svg`
  - Example: `nourion-icon-project-blue.svg`
  - Example: `nourion-icon-project-mono.svg`

### Quality Standards
- ✅ Pixel-perfect على grid 24×24
- ✅ كل الـ paths مدمجة (single path per icon if possible)
- ✅ Stroke width consistent (لو outline style)
- ✅ Corners rounded بنفس الـ radius
- ✅ كل أيقونة optically balanced (مش مرفوعة ولا مخفّضة)

### Optional Bonus
- Animated SVG variants (للأيقونات المهمة فقط)
- Lottie files للأنيميشن المتقدم

---

## 💼 Where to Hire (المنصات الموصى بها)

### Top Choices

#### 1. **Fiverr** ⭐ (الأسرع والأرخص)
- **URL:** https://www.fiverr.com/categories/graphics-design/icon-design
- **Budget:** $50 - $300 لـ 60 أيقونة
- **Timeline:** 5-10 أيام
- **Top sellers:** ابحث "duotone icon set" أو "saas icon set"

#### 2. **99designs** ⭐⭐ (الأفضل للجودة)
- **URL:** https://99designs.com/icon-design
- **Budget:** $399 - $1,500
- **Timeline:** 7-14 يوم (مسابقة بين عدة مصممين)
- **يطلع لك 20+ تصميم تختار أفضله**

#### 3. **Upwork** (للمشاريع طويلة الأمد)
- **URL:** https://www.upwork.com/services/design/icon
- **Budget:** $200 - $2,000
- **Timeline:** يعتمد على المصمم
- **افضل لو بدك علاقة طويلة (تطورات لاحقة)**

#### 4. **Behance / Dribbble** (للنخبة)
- ابحث عن مصممين متخصصين بـ icon sets
- أرسلهم رسالة مباشرة
- **Budget:** $1,500+

#### 5. **Toptal / Designstripe** (للمشاريع الكبيرة)
- مصممين top 3% عالمياً
- **Budget:** $5,000+

---

## 📝 Sample Message للمصمم

```
السلام عليكم،

عندي مشروع SaaS منصة تصنيع اسمها NouRion. محتاج 60 أيقونة بستايل duotone (شبيه Phosphor Icons) بالألوان والمواصفات في الـ brief المرفق.

ما عندي:
- ✓ Brand colors محددة (azure blue + amber + coral)
- ✓ Logo جاهز
- ✓ Style references (Phosphor, Streamline)
- ✓ قائمة الـ 60 أيقونة بالتفصيل

محتاج:
- SVG files (master + 4 color variants + mono)
- Figma file منظم
- Right to use commercially

عرضك وسعرك لو سمحت؟
```

---

## 💰 Budget Recommendations

| Tier | Cost | Use Case |
|------|------|----------|
| **Budget** | $50-150 | استخدام داخلي، MVP |
| **Standard** ⭐ | $300-800 | لـ launch المنتج |
| **Premium** | $1,500-3,000 | إذا بدك مصمم متفرغ + برانديك كامل |
| **Enterprise** | $5,000+ | فريق محترف + animations |

---

## 📅 Timeline

- **Day 1:** اختار المنصة + ارسال Brief
- **Day 2-3:** Negotiate + sign contract
- **Day 4-12:** المصمم يشتغل (مع 2-3 review rounds)
- **Day 13-14:** Final delivery + integration

**Total: 2 أسابيع تقريباً**

---

## ✅ ما يجب أن تتأكد منه قبل الدفع

- [ ] تطلب 3 أيقونات sample قبل الالتزام بالـ 60
- [ ] تتفق على Right to Use Commercially
- [ ] تطلب Figma source files (مش بس SVG)
- [ ] تتفق على عدد الـ revisions (2-3 على الأقل)
- [ ] تشترط delivery in stages (15 → 30 → 60)
- [ ] الـ Payment escrow (مش مباشر)

---

## 🚀 بعد ما تستلم الأيقونات

أعطيني الـ folder اللي فيه كل الـ SVGs، وأنا بـ:
1. أربطهم في كل صفحات NouRion
2. أبدل كل الـ icons الحالية
3. أبني icon helper component للاستخدام المتسق
4. أصدر brand book نهائي

---

**جاهز لأي سؤال حول الـ brief، أو ممكن أعدّل أي قسم.**
